def joke():
	return ("poop")

